import { Component, OnInit } from '@angular/core';
import { ExampleService } from './service/example.service';

@Component({
  selector: 'app-list-example',
  templateUrl: './list-example.component.html',
  styleUrls: ['./list-example.component.scss']
})
export class ListExampleComponent implements OnInit {

  // items = new Array(100);

  users: any = [];



  constructor(
    private exampleService: ExampleService
  ) { }

  ngOnInit(): void {
    this.exampleService.getUsers()
      .subscribe((users) => {
        console.log('users', users)
        this.users = users
      })
  }

  trackById(index: number, item: any) {
    return item.id
  }

}
