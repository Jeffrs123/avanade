import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
// import { Observable, of } from 'rxjs';
import { of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';

const routes = {
  users: () => `/users`,  // quote: (c: RandomQuoteContext) => `/jokes/random?category=${c.category}`,
};

@Injectable({
  providedIn: 'root'
})
export class ExampleService {

  constructor(private httpClient: HttpClient) { }

  // getUsers(): Observable<string> {
  getUsers() {
    return this.httpClient.get(routes.users()).pipe(
      // map((body: any) => body.value),
      catchError(() => of('Error, could not load users :-('))
    );
  }
}
